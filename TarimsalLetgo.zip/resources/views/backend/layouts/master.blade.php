@include('backend.layouts.header')
@include('backend.layouts.sidebar')
@yield('content')
@include('backend.layouts.footer')
