<?php $__env->startSection('content'); ?>
    <div class="site-blocks-cover overlay" style="background-image: url('<?php echo e(asset('frontend/')); ?>/images/site-bg.jpg');"
         data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row align-items-center justify-content-center text-center">

                <div class="col-md-10" data-aos="fade-up" data-aos-delay="400">


                    <div class="row justify-content-center mt-5">
                        <div class="col-md-8 text-center">
                            <h1>Ads Listings</h1>
                            <p class="mb-0">Choose product you want</p>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <div class="site-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <div class="row">

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4">

                                <div class="d-block d-md-flex listing vertical">
                                    <a href="<?php echo e(route('single',['id'=>$product->id,'slug' => $product->slug])); ?>"
                                       class="img d-block"
                                       style="background-image: url('<?php echo e($productImages[$loop->index]->url); ?>');"></a>
                                    <div class="lh-content">
                                        <span class="category"><?php echo e($product->getCategory->name); ?></span>
                                        <h3><a href="#"><?php echo e($product->name); ?></a></h3>
                                        <address>Locationk</address>
                                        <p class="mb-0">
                                            <span class="review"><?php echo e($product->views); ?> Görüntüleme</span>
                                        </p>
                                    </div>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                    <?php if($products->lastPage()>1): ?>
                        <div class="col-12 mt-5 text-center">
                            <div class="custom-pagination">
                                <?php if($products->currentPage()==1): ?>
                                    <span>1</span>
                                <?php else: ?>
                                    <a href="<?php echo e($products->url(1)); ?>">1</a>
                                <?php endif; ?>
                                <?php for($i=2;$i<$products->lastPage();$i++): ?>
                                    <?php if($products->currentPage()==$i): ?>
                                        <span><?php echo e($i); ?></span>
                                    <?php else: ?>
                                        <a href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>

                                    <?php endif; ?>
                                <?php endfor; ?>
                                <?php if($products->currentPage()==$products->lastPage()): ?>
                                    <span><?php echo e($products->currentPage()); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>


                    <?php endif; ?>
                </div>


            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\TarimsalLetgo\resources\views/frontend/products.blade.php ENDPATH**/ ?>